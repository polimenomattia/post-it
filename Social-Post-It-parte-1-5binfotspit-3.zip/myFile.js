let fs = require('fs')
// aggiunge un elemento al file json
function addElementToJSON(jsonData, element) {
  jsonData.push(element)
}
// scrive nel file json
function writeFileJSON(file, dataJSON) {
  fs.writeFile(file, JSON.stringify(dataJSON), (err) => {
    if (err) {
      throw err;
    } else
      console.log('i dati li ho scritti nel file person.json');
  })
}
// legge dal file json
function readFile(percorsoFile) {
  var data;
  data = fs.readFileSync(percorsoFile, "utf8", (err, dati) => {
    if (err) {
      console.error(err);
      return;
    } else {
      return dati;
    }
  });
  return JSON.parse(data);
}
// esporti le funzioni 
module.exports = { addElementToJSON: addElementToJSON, writeFileJSON: writeFileJSON, readFile: readFile }