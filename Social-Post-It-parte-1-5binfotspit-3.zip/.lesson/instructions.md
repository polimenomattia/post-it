# Instructions  

/*
 https://dev.to/thormeier/fully-responsive-html-css-sticky-note-4okl
https://codepen.io/JoshuaDraxten/pen/AaQvWr

Attenzione creare un front end di post it come desiderate con tecnologia bs5 

*/

  ## Steps
  1. scegliere il tipo di post it che sostituirà la riga della tabella
  2.  provare con un solo post it
  3.  provare con n postit e controllare che deve essere responsive
  4. 
  5. 

  
  